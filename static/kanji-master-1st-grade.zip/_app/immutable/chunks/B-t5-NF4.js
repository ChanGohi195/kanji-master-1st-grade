function o(n){return{0:"❓",1:"🌱",2:"🌿",3:"🌳",4:"🌸",5:"💮"}[n]}function e(n){return{0:"まだ",1:"はじめて",2:"れんしゅうちゅう",3:"とくい",4:"マスター",5:"かんぺき"}[n]}export{e as a,o as g};
